public interface ChampionshipManager {
void newDriver();
void changeDriver();
void deleteDriver();
void statisticsDriver();
void tableViewDriver();
void addRace();
}
