import javax.swing.*;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;

public class test {
    public static void main(String[] args) {
//        tab
////        Sing[][]=
//        test  t =new test();
//        t.randomGenerate();
        int randPoint = ThreadLocalRandom.current().nextInt(1,11);
        for (int i=0;i<10;i++){
            System.out.println(randomNumber(1,10));
        }
    }
    int randPoint = ThreadLocalRandom.current().nextInt(1,11);
    public static void tableMeathod(){
        JFrame f;

            f=new JFrame();
            String data[][]={ {"101","Amit","670000"},
                    {"102","Jai","780000"},
                    {"101","Sachin","700000"}};
            String column[]={"ID","NAME","SALARY"};
            JTable jt=new JTable(data,column);
            jt.setBounds(30,40,200,300);
            JScrollPane sp=new JScrollPane(jt);
            f.add(sp);
            f.setSize(300,400);
            f.setVisible(true);


}
    public static int randomNumber(int startNumber, int endNumber){
        return (int) Math.round(Math.random()*(endNumber-startNumber));
    }

//    public LocalDate dateGenerate() {
//        int day = randomDate(1, 28);
//        int month = randomDate(1, 12);
//        int year = randomDate(2020, 2021);
//        LocalDate date = LocalDate.of(year, month, day);
//        System.out.println(date);
//        return date;
//    }

    public Date randomGenerate(){
        int day = randomNumber(1, 28);
        int month = randomNumber(1, 12);
        int year = randomNumber(2020, 2021);

//        String dateConcat = String.format("%d%m%y",year,month,day);
//        System.out.println(dateConcat+" string date");

        Date randDate  = new Date(year, month, day);
        System.out.println(randDate);
        //System.out.println(randDate.getYear());
        return randDate;
    }

//    private String toString(int i) {
//        return null;
//    }

//Add a button and a textbox which can be used to search for all races that a given driver
//participated. The full details of the races should be displayed (i.e. both the dates and
//the positions of the driver in the matching races).

    public int driverSearch(String name){

        if (Formula1ChampionshipManager.driver.isEmpty()) {
            System.out.println("Formula 1 Table is empty,and therefore cannot show any drivers");
            return -2;

        }else{
            for (Formula1Driver driver : Formula1ChampionshipManager.driver) {
                if (driver.getDriverName().equals(name)) {
                    return Formula1ChampionshipManager.driver.indexOf(driver);
                }
            }

        }
        return  -1;
    }

}
